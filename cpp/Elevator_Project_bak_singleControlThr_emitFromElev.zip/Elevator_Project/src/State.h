/*
 * State.h
 *
 *  Created on: Apr 22, 2015
 *      Author: bengteh
 */

#ifndef STATE_H_
#define STATE_H_

#include <ace/Message_Block.h>


namespace Elevator
{
	class State //: public ACE_Data_Block
	{
		//use DAta block object and change udp to send message_block (essentially pointer to data blocks)?
		//
		//dataBlock=direction;
		//dataBlock2=floor;
	};
}




#endif /* STATE_H_ */
